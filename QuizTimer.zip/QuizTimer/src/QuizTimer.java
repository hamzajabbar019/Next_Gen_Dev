import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class QuizTimer {

    private int currentQuestion = 0;
    private int score = 0;
    private List<Question> questions;

    public QuizTimer() {
        questions = new ArrayList<>();
        addQuestions();
        startQuiz();
    }

    private void addQuestions() {
        questions.add(new Question("What is the capital of France?", new String[]{"Paris", "London", "Berlin", "Rome"}, 0));
        questions.add(new Question("What is the capital of Germany?", new String[]{"Paris", "London", "Berlin", "Rome"}, 2));
        questions.add(new Question("What is the capital of Italy?", new String[]{"Paris", "London", "Berlin", "Rome"}, 3));
    }

    private void startQuiz() {
        if (hasMoreQuestions()) {
            Question currentQuestion = getCurrentQuestion();
            displayQuestion(currentQuestion);
            int userAnswer = getUserAnswer();
            checkAnswer(currentQuestion, userAnswer);
            incrementCurrentQuestion();
            startQuiz();
        } else {
            displayResult();
        }
    }

    private boolean hasMoreQuestions() {
        return currentQuestion < questions.size();
    }

    private Question getCurrentQuestion() {
        return questions.get(currentQuestion);
    }

    private void displayQuestion(Question question) {
        System.out.println(question.getQuestion());
        for (int i = 0; i < 4; i++) {
            System.out.println((i + 1) + ". " + question.getOptions()[i]);
        }
    }

    private int getUserAnswer() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter your answer (1-4): ");
        return scanner.nextInt() - 1;
    }

    private void checkAnswer(Question question, int userAnswer) {
        if (userAnswer == question.getCorrectAnswer()) {
            score++;
        }
    }

    private void incrementCurrentQuestion() {
        currentQuestion++;
    }

    private void displayResult() {
        System.out.println("Quiz finished!");
        System.out.println("Score: " + score + "/" + questions.size());
    }

    private class Question {
        private String question;
        private String[] options;
        private int correctAnswer;

        public Question(String question, String[] options, int correctAnswer) {
            this.question = question;
            this.options = options;
            this.correctAnswer = correctAnswer;
        }

        public String getQuestion() {
            return question;
        }

        public String[] getOptions() {
            return options;
        }

        public int getCorrectAnswer() {
            return correctAnswer;
        }
    }

    public static void main(String[] args) {
        new QuizTimer();
    }
}