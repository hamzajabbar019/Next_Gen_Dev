import java.util.Random;
import java.util.Scanner;

public class NumberGame {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        boolean playAgain = true;
        int totalScore = 0;
        int roundNumber = 0;

        System.out.println("Welcome to the Number Guessing Game!");
        System.out.println("Try to guess the number I have selected between 1 and 100.");

        while (playAgain) {
            roundNumber++;
            totalScore += playRound(input);

            System.out.print("Do you want to play another round? (yes/no): ");
            String response = input.next();
            playAgain = response.equalsIgnoreCase("yes");
        }

        System.out.println("Game Over! You played " + roundNumber + " rounds.");
        System.out.println("Your total score is: " + totalScore);

        input.close();
    }

    public static int playRound(Scanner input) {
        Random rand = new Random();
        int numberToGuess = rand.nextInt(100) + 1;
        int numberOfTries = 0;
        int maxAttempts = 10;

        System.out.println("\nStarting a new round...");
        System.out.println("You have " + maxAttempts + " attempts to guess the number.");

        while (numberOfTries < maxAttempts) {
            int guess = 0;
            boolean validGuess = false;

            // Ensure the user enters a valid number within the range
            while (!validGuess) {
                System.out.print("Enter your guess (1-100): ");
                if (input.hasNextInt()) {
                    guess = input.nextInt();
                    if (guess >= 1 && guess <= 100) {
                        validGuess = true;
                    } else {
                        System.out.println("Invalid input! Please enter a number between 1 and 100.");
                    }
                } else {
                    System.out.println("Invalid input! Please enter a number between 1 and 100.");
                    input.next(); // Clear the invalid input
                }
            }

            numberOfTries++;

            if (guess < numberToGuess) {
                System.out.println("Too low! Try again.");
            } else if (guess > numberToGuess) {
                System.out.println("Too high! Try again.");
            } else {
                System.out.println("Congratulations! You guessed the number in " + numberOfTries + " tries.");
                return numberOfTries; // Return number of tries used (win or lose)
            }
        }

        System.out.println("Sorry, you've used all your attempts. The correct number was " + numberToGuess + ".");
        return numberOfTries; // Return number of tries used even if lost
    }
}
